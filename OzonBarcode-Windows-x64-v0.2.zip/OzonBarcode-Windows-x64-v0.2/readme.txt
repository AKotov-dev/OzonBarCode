This package includes adb.exe and libraries from Android SDK under Apache License 2.0.

