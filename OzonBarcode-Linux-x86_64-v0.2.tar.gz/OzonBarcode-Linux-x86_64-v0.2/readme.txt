Included third-party components:

adb, adb.exe and related Android SDK libraries
   License: Apache License, Version 2.0
   Source: https://developer.android.com/studio/releases/platform-tools
   NOTICE: All copyright notices and license conditions are preserved.

